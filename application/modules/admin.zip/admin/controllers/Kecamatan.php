<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Kecamatan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('admin/Kursus_model');
    }

    function index()
    {
        $kecamatan = $this->Kursus_model->listingKec();
        $zonasi = $this->Crud_model->listing('tbl_zonasi');

        $data = [
            'title'   => 'Registrasi || Ananda Private',
            'add'       => 'admin/kecamatan/add',
            'kecamatan'  => $kecamatan,
            'zonasi'  => $zonasi,
            'content'   => 'admin/kecamatan/index'
        ];

        $this->load->view('layout/wrapper', $data, FALSE);
    }

    function add()
    {
        $this->load->helper('string');

        $kabupaten = $this->Crud_model->listing('tbl_kabupaten');
        $zonasi = $this->Crud_model->listing('tbl_zonasi');
        $valid = $this->form_validation;
        $valid->set_rules('nama_kecamatan', 'Nama Kecamatan', 'required', ['required' => '%s tidak boleh kosong']);

        if ($valid->run()) {
            $data = array(
                'id_kecamatan'  => random_string('numeric', 6),
                'nama_kecamatan'      => $this->input->post('nama_kecamatan'),
                'id_kabupaten'      => $this->input->post('id_kabupaten'),
                'id_zonasi'      => $this->input->post('id_zonasi'),
            );
            $this->Crud_model->add('tbl_kecamatan', $data);
            $this->session->set_flashdata('msg', 'Kecamatan ditambah');
            redirect('admin/kecamatan', 'refresh');
        }
        $data = [
            'title'   => 'Kecamatan || Ananda Private',
            'kabupaten'  => $kabupaten,
            'zonasi'  => $zonasi,
            'content'   => 'admin/kecamatan/add'
        ];

        $this->load->view('layout/wrapper', $data, FALSE);
    }
    function edit($id_kecamatan)
    {
        $kecamatan = $this->Crud_model->listingOne('tbl_kecamatan', 'id_kecamatan', $id_kecamatan);
        $zonasi = $this->Crud_model->listing('tbl_zonasi');
        $valid = $this->form_validation;
        $valid->set_rules('nama_kecamatan', 'Nama Kecamatan', 'required', ['required' => '%s tidak boleh kosong']);

        if ($valid->run()) {
            $data = array(
                'id_kecamatan'      => $kecamatan->id_kecamatan,
                'nama_kecamatan'      => $this->input->post('nama_kecamatan'),
                'id_zonasi'      => $this->input->post('id_zonasi')
            );
            $this->Crud_model->edit('tbl_kecamatan', 'id_kecamatan', $id_kecamatan, $data);
            $this->session->set_flashdata('msg', 'Kecamatan diedit');
            redirect('admin/kecamatan', 'refresh');
        }
        $data = [
            'title'     => 'Kecamatan || Ananda Private',
            'kecamatan'  => $kecamatan,
            'zonasi'  => $zonasi,
            'content'   => 'admin/kecamatan/edit'
        ];

        $this->load->view('layout/wrapper', $data, FALSE);
    }

    function delete($id_kecamatan)
    {
        $this->Crud_model->delete('tbl_kecamatan', 'id_kecamatan', $id_kecamatan);
        $this->session->set_flashdata('msg', 'dihapus');
        redirect('admin/kecamatan');
    }
}
