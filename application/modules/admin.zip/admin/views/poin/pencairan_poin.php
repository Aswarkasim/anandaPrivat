<div class="col-xs-14 col-sm-14 col-md-14 col-lg-14 col-xl-11">
    <div class="wt-dashboardbox">
        <div class="wt-dashboardboxtitle">
            <h2>Pencairan Poin</h2>
        </div>
        <div class="wt-dashboardboxcontent wt-rcvproposala">
            <div class="wt">
                <div class="container-fluid"><br><br>
                    <table class="table table-hover DataTables">
                        <thead class="text-white" style="background-color:#ff5851">
                            <tr>
                                <th width="50px">No</th>
                                <th width="200px">Tanggal</th>
                                <th>Nama Tentor</th>
                                <th width="150px">Jumlah Poin</th>
                                <th width="100px">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <tr>
                                <td>1</td>
                                <td>27/07/2019</td>
                                <td>Bapak Rahman</td>
                                <td>Rp 50.000,-</td>
                                <td>
                                    <button class="wt-btn btn-sm">Cairkan</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <br><br>
                </div>

            </div>
        </div>                             
    </div>
</div>