<main id="wt-main" class="">
    <!--Sidebar Start-->

    <div class="col-md-8 mx-auto">
        <div class="wt-haslayout wt-dbsectionspace">
            <div class="wt-dashboardbox wt-dashboardtabsholder">
                <div class="wt-dashboardboxtitle">
                    <h2>Pesan</h2>
                </div>
                <div style="width: 100%;" class="wt-tabscontent tab-content">
                    <div class="wt-personalskillshold tab-pane active fade show" id="wt-skills">
                        <div class="wt-skills">
                            <div class="wt-tabscontenttitle mb-0">
                                <h2>Kirim Pesan</h2>
                            </div>
                            <div class="wt-skillscontent-holder">
                                <div class="wt-myskills mt-0">
                                    <div class="col-12">
                                        <div class="wt-haslayout wt-dbsectionspace ">
                                            <div class="wt-dashboardbox ">
                                                <div class="container">
                                                    <div class="form-group">
                                                        <label for=""><strong>Kepada</strong></label>
                                                        <input type="text" name="" class="form-control" placeholder="Username/Email">
                                                    </div>

                                                    <div class="form-group">
                                                        <label for=""><strong>Judul Pesan</strong></label>
                                                        <input type="text" name="" class="form-control" placeholder="">
                                                    </div>

                                                    <script>
                                                        CKEDITOR.replace("#editor");
                                                    </script>

                                                    <div class="form-group">
                                                        <label for=""><strong>DESKRIPSI</strong></label>
                                                        <textarea placeholder="Ketik Pesan . . ." name="deskripsi" id="editor" style="heigth:100px;" cols="300" rows="100"></textarea>
                                                    </div>

                                                    <div class="form-group">
                                                        <button type="submit" class="wt-btn"><i class="fa fa-save"></i> Simpan</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    ClassicEditor
        .create(document.querySelector('#editor'), {
            toolbar: ['bold', 'italic', 'link']
        })
        .catch(error => {
            console.log(error);
        });
</script>